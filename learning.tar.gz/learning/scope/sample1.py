
a=1

def func():
        a=1
        print(a)
        a=2
        print(a)

func()
print(a)