
def a():
        while True:
                x = yield
                print('a:{}'.format(x))
                if not x:
                        break
        return range(3)


def b():
        print('b')
        x=yield from a()
        print('x:{}'.format(x))

print(1)

b1=b()
b1.send(None)
for x in [1,2,3]:
        print(x)
        b1.send(x)
try:
        b1.send(None)
except StopIteration as e:
        print(e.value)