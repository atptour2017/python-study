def gen_func():
    yield 1
    name = "bobby"
    yield 2
    age = 30
    return "imooc"

import dis
gen = gen_func()
for x in gen:
        print(x)
print(gen)
# print (dis.dis(gen))
#
# print(gen.gi_frame.f_lasti)
# print(gen.gi_frame.f_locals)
# next(gen)
# print(gen.gi_frame.f_lasti)
# print(gen.gi_frame.f_locals)
# next(gen)
# print(gen.gi_frame.f_lasti)
# print(gen.gi_frame.f_locals)