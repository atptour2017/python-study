

def gen_func():
    #1. 可以产出值， 2. 可以接收值(调用方传递进来的值)
    html = yield "http://projectsedu.com"
    print(html)
    yield html
    yield 1
    yield 2
    yield 3
    yield 4
    return "bobby"

if __name__=='__main__':
    gen=gen_func()
    url = next(gen)
    print(url)
    #download url
    a = "https://www.baidu.com"
    print(gen.send(a))
    gen.close()

