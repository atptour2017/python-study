from itertools import chain

my_list = [1,2,3]
my_dict = {
    "bobby1":"http://projectsedu.com",
    "bobby2":"http://www.imooc.com",
}

def my_chain(*args, **kwargs):
    for my_iterable in args:
        print(my_iterable)
        yield from my_iterable

def g1(iterable):
    yield from iterable

def g2(iterable):
    for x in iterable:
        yield x

if __name__=='__main__':

    value=my_chain(my_list, my_dict, range(5,10))
    print(value)
    # for x in g1(g2(range(10))):
    #     print(x)