class Rational:
        @staticmethod
        def _gcd(m,n):
                print(m,n)
                if n==0:
                        m,n=n,m
                while m!=0:
                        m,n=n%m,m
                print(m,n)
                return n

        def __init__(self,num,den=1):
                sign=1
                if num<0:
                        num,sign=-num,-sign
                if den<0:
                        den,sign=-num,-sign

                g=Rational._gcd(num,den)
                print(g)
                self._num=sign*(num//g)
                print(self._num)
                self._den=den//g
                print(self._den)

a=Rational(5,13)
