
def func(aiter):
        yield from aiter
        return None

a=(1,2,3,4)
for i in func(a):
        print(i)