
def func():
        n=yield x
