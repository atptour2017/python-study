
def fabonacci(n):
        a=0
        b=1
        for _ in range(n):
                b,a=a+b,b
                yield a
        return b

for i in fabonacci(5):
        print(i)