
def a(*args, **kwargs):
        for i in args:
                print(i)
        print(kwargs)
        for key in kwargs:
                print(key,kwargs[key])

if __name__=='__main__':
        x=range(10)

        a(*x,a=2,b=3)
