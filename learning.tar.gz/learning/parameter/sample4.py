
def func(a,b=0,*args,**kwargs):
        print(a)
        print(b)
        print(args)
        print(kwargs)

def func1(*args,**kwargs):
        print(args)
        print(kwargs)

def func2(*args,a,b=None,**kwargs):
        print(args)
        print(a)
        print(b)
        print(kwargs)


def func3(*aa,**bb):
        print(aa)
        print(bb)

#func(0,1,2,3,4,5,6,x=1,y=2)
#func1(0,1,2,3,4,5,6,x=1,y=2)
d={'c':2,'d':4}
#func2(*range(4),a=0,b=1,**d)
#func2(1,2,3,4,a=0,b=1,c=2,d=4)
func3(*range(4),a=1,b=2)