#  *运算符把可迭代对象拆开作为函数的参数

def func(x,y):
        print(x*y)


a=[2,3]
a=(3,4)
func(*a)

func(3,4)