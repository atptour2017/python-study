def function(*args):
    print(args, type(args))
    for i in args:
            print(i)

a=[1,2,3,4]
function(*a)
function(1,2,3,4)

def function(x, y, *args):
    print(x, y, args)

function(1, 2, 3, 4, 5)