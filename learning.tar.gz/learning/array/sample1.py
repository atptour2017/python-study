from array import array

f=array('d')
f.append(1)
f.append(2)
f.append(3)
print(f)
g=array('i')
for i in range(10):
        g.append(i)
print(g)