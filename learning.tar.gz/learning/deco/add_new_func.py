
def deco(func):
        def new_func(*args,**kwargs):
                print('in new func')
                func(*args,**kwargs)
        return new_func

@deco
def func(x,y,z,*args,**kwargs):
        print('in func')
        print(x)
        print(y)
        print(z)
        print(args)
        print(kwargs)

func=deco(func)
func(1,2,3,4,5,6,a=9,b=10)