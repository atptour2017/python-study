def deco2(func):
        def inner2(*args,**kwargs):
                print('running inner2()')
                func(*args,**kwargs)
        return inner2

def deco(func):
        def inner(*args,**kwargs):
                print('running inner()')
                func(*args,**kwargs)
        return inner

@deco2
@deco
def target(x,y):
        print('running target()')
        print(x*y)

if __name__=='__main__':
        target(2,3)
        print(target.__name__)