def foo():
        while True:
                food = yield 'abc'
                print(food)

f=foo()
f.send(None)
a=f.send('apple')
print(a)
f.close()